const NewGameButton = (props) => (
  <button className="btn btn-default">
    New Game
  </button>
);

export default NewGameButton;
