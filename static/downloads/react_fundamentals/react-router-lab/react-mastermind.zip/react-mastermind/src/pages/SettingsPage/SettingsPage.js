import { Link } from 'react-router-dom';

const SettingsPage = (props) => (
    <div>
        <Link to="/">Home</Link>
        <h1>Settings Page</h1>
    </div>
);

export default SettingsPage;