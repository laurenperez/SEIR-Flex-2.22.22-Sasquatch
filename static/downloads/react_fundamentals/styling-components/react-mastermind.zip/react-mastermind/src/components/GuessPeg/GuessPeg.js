const GuessPeg = (props) => (
  <div>
    {props.color}
  </div>
);

export default GuessPeg;
