// local constant for holding the URL to our api
const BASE_URL = 'http://localhost:3001/api';


// named export of function for making AJAX request
export function fetchScoreData() {
    return fetch(BASE_URL + '/scores').then(res => res.json());
}
