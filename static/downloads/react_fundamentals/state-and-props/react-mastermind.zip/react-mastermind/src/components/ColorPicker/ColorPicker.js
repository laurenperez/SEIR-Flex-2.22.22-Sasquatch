const ColorPicker = (props) => (
  <div>
    ColorPicker
  </div>
);

export default ColorPicker;
