const GuessScore = (props) => (
  <div>
    GuessScore
  </div>
);

export default GuessScore;
