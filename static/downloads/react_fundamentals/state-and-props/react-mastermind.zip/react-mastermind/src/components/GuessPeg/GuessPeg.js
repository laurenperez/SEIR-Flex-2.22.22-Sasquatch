const GuessPeg = (props) => (
  <div>
    GuessPeg
  </div>
);

export default GuessPeg;
