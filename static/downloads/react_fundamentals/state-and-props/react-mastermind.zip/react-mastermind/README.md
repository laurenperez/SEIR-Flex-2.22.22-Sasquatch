# React Mastermind

A classic board game turned React App, with a twist! This game can be played with one player ass the React App itself is the mastermind.


## What's with this version?
This very has most of the components created in boilerplate form arranged in a simple layout.

## Change log
1. React app scaffolded
2. Small changes to `App.css`
3. Basic component structure defined with component boilerplates
4. The red border styling removed
5. An additional <ScoreButton> component has been defined, but not rendered yet
6. React import removed in component per the [latest update to React](https://reactjs.org/blog/2020/09/22/introducing-the-new-jsx-transform.html)