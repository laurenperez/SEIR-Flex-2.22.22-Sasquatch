const BASE_URL = 'http://localhost:3001/api';


export function fetchScoreData() {
    return fetch(BASE_URL + '/scores').then(res => res.json());
}

export function addScoreData(score) {
    const options = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify(score)
    };
    return fetch(BASE_URL + '/scores', options).then(res => res.json());
}