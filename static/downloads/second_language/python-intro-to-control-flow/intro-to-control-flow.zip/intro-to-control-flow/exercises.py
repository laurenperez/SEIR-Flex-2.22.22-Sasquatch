# Branching & Looping Exercises

color = input('Enter "green", "yellow", "red": ').lower()
print(f'The user entered {color}')

# Write the if...elif...else statement as described in the lesson